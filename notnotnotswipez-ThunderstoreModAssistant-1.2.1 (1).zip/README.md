### Join my [Discord Server](https://discord.gg/c74mqPuQaV) for support or updates on future stuff

# What is this mod?
This mod allows you to manage mods off of Thunderstore while ingame. This is mostly designed for Quest users but PC users can still benefit in some aspects.

# ```Features```
- Custom UI
- Quest Support
- Code mod downloading ingame
- Code mod update alerts

# How do I use this?
Go ingame and open Bonemenu, after opening the ThunderstoreModAssistant category, the UI should open. Navigating the UI should be simple, it includes a search bar and notification tray.
You can use the search bar to search across Thunderstore for Code mods, and the notification tray will notify you when any code mods you've downloaded have an available update.

Clicking the button in the top left corner will switch between your installed mods and Thunderstores latest updated category.

The mod does not hot-reload mods live. A game restart is required after. This is intentional.

## ```Installation```
### Drag the ThunderstoreModAssistant dll from "Mods" into your Mods folder. 
### Drag the ThunderstoreModAssistantPlugin dll from "Plugins" into your Plugins folder. 
### Drag the Newtonsoft.Json dll from "Melonloader/Managed" to your "Melonloader/Managed" folder (Replace it) (Unnecessary on LemonLoader or ML 0.6.5+)

# Changelog
# 1.2.1
- Failsafe added for duplicate temp.zip error
# 1.2.0
- The mod will now auto delete mods that are added to the blacklist mastersite if they are previously installed.
# 1.1.0
- Blacklisted mods that do not function 
# 1.0.0
- Release

Commissioned by [MinibattleLop](https://www.reddit.com/r/virtualreality/comments/1csec4w/comment/l4a2awd/)